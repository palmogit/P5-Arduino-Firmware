#include <Streaming.h>
#include <OneWire.h>
#include <owKam.h>
#define WEBDUINO_SERIAL_DEBUGGING 0
#define WEBDUINO_FAIL_MESSAGE "<h1>Request Failed</h1>"
#include "avr/pgmspace.h" // new include
#include <avr/wdt.h>
#include "SPI.h" // new include
//#define Ethernet2_board // <<<< we don't have Ethernet2 boards in UXC-P5 for the arduino system
#if defined(Ethernet2_board)
#include "Ethernet2.h"
#else
#include "Ethernet.h"
#endif

#include "WebServer.h"
#include "Webdefault.h"

//============================================================
//===== DEVICES UNDER THE   188.184.YYY.XXX    NETWORK ADDRESS
//============================================================
//byte mac[] = { 0x00, 0x60, 0x35, 0x00, 0x8D, 0xA4 }; // ATMEGA6   // 188.184.9.154 // the Cooling Bundles Mockup Arduino
//byte mac[] = { 0x90, 0xA2, 0xDB, 0x7C, 0xE6, 0x9C }; // ATMEGAK01 // 188.184.9.181 // bt 186 oulet 0f03/01
//byte mac[] = { 0x90, 0xA2, 0xDB, 0x7C, 0xE6, 0x9d }; // ATMEGAK02 // 188.184.9.189 // bt 186 oulet 0f03/01
byte mac[] = { 0xDE, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE }; // ARDUTEST  // 188.184.9.190 // Test station at 186

//============================================================
//===== DEVICES UNDER THE   137.138.YYY.XXX    NETWORK ADDRESS
//============================================================
//byte mac[] = { 0x00, 0x60, 0x35, 0x00, 0x8D, 0xA4 }; // ATMEGA6  // 137.138.50.172 // the Ettore Arduino
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x10, 0x27, 0xC8 }; // ATMEGAK70 // 137.138.188.247 // PIXEL COFFIN SENSORS

//=========================================================
//===== DEVICES UNDER THE   10.176.2.XXX    NETWORK ADDRESS
//=========================================================
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x00, 0x6E, 0xC9 }; // ATMEGA0 //   142
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x00, 0x40, 0xDC }; // ATMEGA1 //   143
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x00, 0x6E, 0xC2 }; // ATMEGA2 //   144
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x00, 0x6E, 0xE1 }; // ATMEGA3 //   145 // Bulkhead PLUS

//byte mac[] = { 0x90, 0xA2, 0xDA, 0x00, 0x6E, 0xE2 }; // ATMEGA4 //   159 // FOS near
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0D, 0x1F, 0x3D }; // ATMEGA5 //   160 // FOS far // free address now

//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0D, 0x24, 0x81 }; // ATMEGA20 //  147 // Bulkhead MINUS
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0D, 0x41, 0x9F }; // ATMEGA21 //  148
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0D, 0x41, 0xA2 }; // ATMEGA22 //  149
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0D, 0x41, 0x99 }; // ATMEGA23 //  150
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0D, 0x41, 0x7F }; // ATMEGA24 //  151
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0D, 0x41, 0xA3 }; // ATMEGA25 //  152

//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0E, 0x95, 0x7B }; // ATMEGA40 //  164 // CO2 NEAR-SIDE // address also used for bulkhead plus-end 
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0E, 0x9A, 0x39 }; // ATMEGA41 //  165 // CO2 FAR-SIDE

//byte mac[] = { 0x90, 0xA2, 0xDB, 0x7C, 0xE6, 0x9b }; // ATMEGAK04 // 10.176.11.12 // P5 close to pneum cabinet 3524 R-0000, oulet 8401/01
//byte mac[] = { 0x90, 0xA2, 0xDB, 0x7C, 0xE6, 0x9c }; // ATMEGAK05 // 197 // P5 Gas room, cable to SS2, oulet 8401/01
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0F, 0x73, 0x9D }; // ATMEGAK06 // 198 // PIX cooling plant
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0F, 0x73, 0x9E }; // ATMEGAK07 // 199 // TS cooling plant
//byte mac[] = { 0x90, 0xA2, 0xDA, 0x0D, 0x41, 0x9D }; // ATMEGA26  // !! MISSING INFO's ON THAT ONE !!

// ATMEGA0 @P5 
//CURENT ADDRESS HERE: (!! PLEASE CHANGE IT ACCORDINGLY BEFORE TO UPLOAD THE FW TO THE BOARD !!)
//IPAddress ip ( 10, 176, 2, 148);
IPAddress ip ( 188, 184, 9, 190);


int cnt;
int LED_PIN=47;
//int LED_PIN=52;    // for hand made board with LCD
bool LED_ON=false;
int LED_DS=100;

//int nSensors=sizeof(shts)/sizeof(Sht); // only SHT sensors

WebServer webserver(PREFIX, 80);
int verbose=0;

bool SequentialConversion = true;
uint8_t Resolution_T = 12;

// enable all 1-wire pins
owPin owPins[] ={ owPin(2), owPin(3), owPin(5), owPin(6), owPin(7), owPin(8), owPin(9), owPin(11), owPin(12), owPin(44), owPin(46)};
int NowPins=sizeof(owPins)/sizeof(owPin);

owT *owTs=NULL;
int NowTs=0; // number of T sensors
owRH *owRHs=NULL;
int NowRHs=0; // number of RH sensors
ScratchPad scratchPad;

// strange Franz's normalization with his comment
float coefficient=0.983658; // because of adc1 to adc2 calibration

void flipLed() {
  if (LED_ON) {
    digitalWrite(LED_PIN,0);
    LED_ON=false;
  } else {
    digitalWrite(LED_PIN,1);
    LED_ON=true;
  }
  return;
}

void indexCmd(WebServer &server, WebServer::ConnectionType type, char *url_tail, bool tail_complete);
void rawCmd(WebServer &server, WebServer::ConnectionType type, char *url_tail, bool tail_complete);
void parsedCmd(WebServer &server, WebServer::ConnectionType type, char *url_tail, bool tail_complete);
void my_failCmd(WebServer &server, WebServer::ConnectionType type, char *url_tail, bool tail_complete);
void resetCmd(WebServer &server, WebServer::ConnectionType type, char *url_tail, bool tail_complete) {
  server.httpSuccess();
  if (type == WebServer::HEAD)
    return;
  server.printP(Page_start);
  server.print(millis());
  server.printP(Reset);
  server.printP(Page_end);
  server.reset();
  delay(1000);
  software_Reset();
}


void ScanCmd(WebServer &server, WebServer::ConnectionType type, char *url_tail, bool tail_complete)
{
  /* this line sends the standard "we're all OK" headers back to the browser */
  server.httpSuccess();
  if (type == WebServer::HEAD)
    return;
  server.printP(Scan_head);
  server << F("Free RAM ") << freeRam() << "<br>" << endl;
  server << F("(Scanning all the pins <br>") << endl;
  server << F("<tt><pre>");
  ScanAll(server);
  server << F("</pre></tt>");
  for (owT *powT=owTs; powT != NULL && NowTs != 0 ; powT=getNextSensor(powT)) {
    powT->printAddress(server);
    if (powT->isConnected())
      server << F(" is connected <br>") << endl;
    else
      server << F(" is disonnected <br>") << endl;
  }
  for (owRH *powRH=owRHs; powRH != NULL && NowRHs != 0 ; powRH=getNextSensor(powRH)) {
    powRH->printAddress(server);
    if (powRH->isConnected())
      server << F(" is connected <br>") << endl;
    else
      server << F(" is disonnected <br>") << endl;
  }
  server << " Totally: " << " NowTs=" <<  NowTs <<  " NowRHs=" << NowRHs << "<br>" << endl;
  setResolutionAll_T(Resolution_T);

  server << F("Free RAM ") << freeRam() << "<br>" << endl;

  server.printP(Page_end);

}

void readTCmd(WebServer &server, WebServer::ConnectionType type, char *url_tail, bool tail_complete) {
  /* this line sends the standard "we're all OK" headers back to the browser */
  server.httpSuccess();
  if (type == WebServer::HEAD)
    return;
  flipLed();
  server.printP(Read_head);
  server << F("Free RAM ") << freeRam() << "<br>" << endl;
  server << F("(convert/readout all T  <br>") << endl;
  server << F("<tt><pre>");
  server << " Totally: " << " NowTs=" <<  NowTs <<  " NowRHs=" << NowRHs << "<br>" << endl;
  if (SequentialConversion) {
    for (owT *powT=owTs; powT != NULL && NowTs != 0 ; powT=getNextSensor(powT)) {
      powT->setResolution(Resolution_T);

      powT->Convert();
      powT->printAddress(Serial);
      Serial << endl;
      uint8_t status=0x0;
      for (int i=0; i<12 && !status; i++) {
	status = powT->_read();
	Serial.print(status,HEX);  Serial.print(" ");
	delay (100);
      }
      Serial.println();
      powT->printAddress(server);
      powT->readT();
      int erc=powT->erc;
      float t=powT->getTemperature()->value;
      TimeStamp tS=powT->getTemperature()->tStamp;
      server << F(" erc=") << erc <<  F(" Ts=") << tS << F(" T=") << t << endl;
    }
    for (owRH *powRH=owRHs; powRH != NULL && NowRHs != 0 ; powRH=getNextSensor(powRH)) {
      delay(10);
      powRH->printAddress(Serial);
      Serial.println();
      powRH->copy2EEPROM();
      delay(12);
      powRH->Convert();
      delay(12);
      /* Serial << endl; */
      /* uint8_t status=0x0; */
      /* for (int i=0; i<12 && !status; i++) { */
      /* 	 status = powRH->_read(); */
      /* 	 Serial.print(status,HEX);  Serial.print(" "); */
      /* 	 delay (10); */
      /* } */
      powRH->readT();
      powRH->ConvertVDD();
      delay(4);
      powRH->readVDD();
      powRH->calcRhDp();
      powRH->printAddress(server);
      float t=powRH->getTemperature()->value;
      TimeStamp tS=powRH->getTemperature()->tStamp;
      float vad=powRH->getVAD()->value;
      float vdd=powRH->getVDD()->value;
      float Rh=powRH->getRh()->value;
      float Dp=powRH->getDp()->value;
      int erc=powRH->erc;
      TimeStamp tSvdd=powRH->getVDD()->tStamp;
      server  << F(" erc=") << erc << F(" Ts=") << tS  << F(" TsVDD=") << tSvdd
	      << F(" T=") << t  << F(" vad=") << vad << F(" vdd=") << vdd
	      << F(" Rh=") << Rh << F(" Dp=") << Dp << endl;
    }
  } else { // All at the time conversion
    ConvertAll_T();
    delay(DS18B20_CONVERSION_TIME);
    readAll_T();
    for (owT *powT=owTs; powT != NULL && NowTs != 0 ; powT=getNextSensor(powT)) {
      float t=powT->getTemperature()->value;
      TimeStamp tS=powT->getTemperature()->tStamp;
      powT->printAddress(server);
      server << F(" Ts=") << tS << F(" T=") << t << endl;
    }
  }
  server << F("Free RAM ") << freeRam() << "<br>" << endl;
  server.printP(Page_end);
}

void indexCmd(WebServer &server, WebServer::ConnectionType type, char *url_tail, bool tail_complete) {
  server.httpSuccess("text/plain; charset=utf-8",NULL);

  if (type == WebServer::HEAD)
    return;
  flipLed();
  //  for (int i=0; i < nSensors; i++) {   //sht75
  //    server << " " << shts[i].Ts << " " << i << " " <<  shts[i].SensorId << " ";
  //    server << shts[i].Th << " " <<  shts[i].Rh << " " <<  shts[i].Dp;
  //    server << " 0 0 0 0"  << endl;
  //  }
  server << "# TK Arduino v0.2 March 2016" << endl;
  for (owT *powT=owTs; powT != NULL && NowTs != 0 ; powT=getNextSensor(powT)) {
    float t=powT->getTemperature()->value;
    TimeStamp tS=powT->getTemperature()->tStamp;
    //    int erc=0;
    int erc=powT->erc;
    if (erc == 0) {
      server << " " << tS << " ";
      server << powT->getPin() << " ";
      powT->printSensorId(server);
      server  << " "  << t  << " 0 0 0 0 0 "  << erc << endl;
    }
  }
  for (owRH *powRH=owRHs; powRH != NULL && NowRHs != 0 ; powRH=getNextSensor(powRH)) {
    float t=powRH->getTemperature()->value;
    TimeStamp tS=powRH->getTemperature()->tStamp;
    float vad=powRH->getVAD()->value/100;   // in volts
    float vdd=powRH->getVDD()->value/100;   // in volts
    float Rh=powRH->getRh()->value;
    float Dp=powRH->getDp()->value;
    int erc=powRH->erc;
    //    TimeStamp tSvdd=powRH->getVDD()->tStamp;
    if (erc == 0) {
      server << " " << tS << " "  << powRH->getPin() << " ";
      powRH->printSensorId(server);
      server   << " " << t  << " " << Rh  << " "  << Dp << " " << vad << " " << vdd << " " << erc << endl;
    }
  }
}



void setup(void) {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN,1);
  delay(500);
  digitalWrite(LED_PIN,0);
  delay(500);
  digitalWrite(LED_PIN,1);
  delay(500);
  digitalWrite(LED_PIN,0);
  delay(500);
  digitalWrite(LED_PIN,1);

  Serial.begin(9600);
  verbose=11;
  NowPins=sizeof(owPins)/sizeof(owPin);

  Ethernet.begin(mac, ip);
  webserver.setDefaultCommand(&indexCmd);
  webserver.setFailureCommand(&my_failCmd);
  webserver.addCommand("index.html", &indexCmd);

  webserver.addCommand("scan.html", &ScanCmd);
  webserver.addCommand("parsed.html", &parsedCmd);
  webserver.addCommand("reset.html", &resetCmd);
  webserver.addCommand("read.html", &readTCmd);

  // start serial port
  Serial.begin(9600);
  Serial.println("Kaminsky test: mixing the pinguins with parrots");
  Serial << "Free RAM " << freeRam() << endl;
  for (int i=0; i<NowPins; i++) {
    owPins[i].Scan(TRUE);
    if (verbose>5)
      Serial << "**Pin " << owPins[i].getpin() << " nTs="
	     <<  owPins[i].nTs <<  " nRHs=" << owPins[i].nRHs
	     << " NowTs=" <<  NowTs <<  " NowRHs=" << NowRHs << endl;
  }
  setResolutionAll_T(Resolution_T);
  ConvertAll_T();
  delay(DS18B20_CONVERSION_TIME-100);
  if (verbose>10)
    Serial << "Free RAM " << freeRam() << endl;
  digitalWrite(LED_PIN,0);

}


void loop(void) {
  char buff[64];
  int len = 64;
  /*
    for (int i=0; i < nSensors; i++) {
    Sht *sht=&shts[i];
    sht->ReadAll();
    webserver.processConnection(buff, &len);

    Serial.print("sht ");
    Serial.print(i);
    Serial.print(": Th: ");
    Serial.print(sht->Th);
    Serial.print(" C, Rh: ");
    Serial.print(sht->Rh);
    Serial.print(" %, Dp: ");
    Serial.print(sht->Dp);
    Serial.println(" C");
    }
  */
  for (int i=0; i<100; i++) {
    webserver.processConnection(buff, &len);
    delay(10);
  }

  readAll_T();
  webserver.processConnection(buff, &len);
  ConvertAll_T();
  webserver.processConnection(buff, &len);
  ConvertAll_RH_T();
  delay(DS2438_T_CONVERSION_TIME);
  webserver.processConnection(buff, &len);
  readAll_RH_T();
  webserver.processConnection(buff, &len);
  ConvertAll_RH_VDD();
  delay(DS2438_AD_CONVERSION_TIME);
  webserver.processConnection(buff, &len);
  readAll_RH_VDD();
  calcAll_RH_DP();
  webserver.processConnection(buff, &len);

  delay(100);
}
