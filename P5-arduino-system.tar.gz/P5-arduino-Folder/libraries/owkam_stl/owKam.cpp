#include "owKam.h"
using namespace std;

owPin::owPin( int aPin) {
  pin=aPin;
  nSensors=0;
  nTs=0;
  nRHs=0;
  OWHandle=new OneWire((uint8_t) pin);
  Scan(true);
}
owPin::~owPin() {
  delete OWHandle;
}


void owPin::Scan(bool Populate) {
  //  OWHandle->reset();
  OWHandle->Init(pin);
  OWHandle->reset_search();
  for (int i=0; i<8; i++) {
    devAddress[i]=0;
  }
  while ( OWHandle->search(devAddress)) {
    if (devAddress[0] == 0x26) { //RH
      if (verbose>10) 
	printAddress();
      if (Populate && !owExists(devAddress)) { 
	owRHs.push_back(owRH(pin, OWHandle, devAddress));
	nRHs++; nSensors++;
	if (verbose>10) 
	  cout << " New" << endl;
      } else 
	if (verbose>10) 
	  cout << F(" Already Exists") << endl;
    }
    else if (devAddress[0] == 0x28) {  //T
      if (verbose>10) 
	printAddress();
      if (Populate && !owExists(devAddress)) { 
	owTs.push_back(owT(pin, OWHandle, devAddress)); 
	nTs++; nSensors++;
	if (verbose>10) 
	  cout << " New" << endl;
      } else 
	if (verbose>10) 
	  cout << F(" Already Exists") << endl;
    }
    else {
      if (verbose>10) {
	printAddress();
      }
    }
  }
}

void owPin::printAddress() {
    // zero pad the address if necessary

  std::cout << " Pin " << pin;


  if (devAddress[0] == 0x26) {
    Serial.print("  RH/TH ");
  }
  if (devAddress[0] == 0x28) {
    Serial.print(" Tsensor");
  }
  if (devAddress[0] >= 16) {
    Serial.print("(");   Serial.print(devAddress[0], HEX);  Serial.print(") ");
  }   for (uint8_t i = 1; i < 8; i++) {
    if (devAddress[i] < 16) Serial.print("0");
    Serial.print(devAddress[i], HEX);
  }
  //  std::cout << std::endl;
}

owSensor::owSensor(int apin, OneWire *handle,  DeviceAddress address) {
  pin=apin;
  OWHandle=handle;
  for (int i=0; i<8; i++)
    Address[i]=address[i];
  LastData.tstamp=0;
  LastData.Status=-1;
  PrevData.tstamp=0;
  PrevData.Status=-1;
  // if (address[0] == 0x26 ) 
  //   Type=1;
  // if (address[0] == 0x28 ) 
  //   Type=2;
}

bool owExists(DeviceAddress addr) {
  bool found;
  return false;
  for (vector<owT>::iterator it=owTs.begin(); it!=owTs.end(); ++it) {
    found=true;
    for (int i=0; i<8; i++) {
      if (it->getAddressByte(i) != addr[i]) {
	found=false;
	break;
      }      
    }
    if (found)
      return true;
  }
  for (vector<owRH>::iterator it=owRHs.begin(); it!=owRHs.end(); ++it) {
    found=true;
    for (int i=0; i<8; i++) {
      if (it->getAddressByte(i) != addr[i]) {
	found=false;
	break;
      }      
    }
    if (found)
      return true;
  }
  return false;
}

int freeRam () {
  extern int __heap_start, *__brkval;
  int v;
  return (int) &v - (__brkval == 0 ? (int) &__heap_start : (int) __brkval);
}
