#ifndef OneKam_h
#define OneKam_h
#include <inttypes.h>
#include <StandardCplusplus.h>
#include <serstream>
#include <OneWire.h>

extern int verbose;
typedef uint8_t DeviceAddress[8];
typedef struct {
  unsigned long tstamp;
  float Th;
  int Status;
} SensorData;

class owSensor {
 protected:
  uint8_t pin;
  DeviceAddress Address;
  SensorData LastData;
  SensorData PrevData;
  OneWire *OWHandle;
 public:
  owSensor(int apin, OneWire *handle,  DeviceAddress address);
  int Print (char *buffer);
  uint8_t getAddressByte (int b) { return Address[b]; };
};

class owT: public owSensor {
 public:
 owT(int apin, OneWire *handle,  DeviceAddress address) : 
  owSensor(apin, handle, address) {}
};

class owRH: public owSensor {
 public:
 owRH(int apin, OneWire *handle,  DeviceAddress address) : 
  owSensor(apin, handle,  address) {}
};

class owPin {
 private:
  int pin;
  DeviceAddress devAddress;
  
 public:
  int nSensors;
  int nTs;
  int nRHs;
  owPin();
  ~owPin();
  owPin( int aPin);
  int getpin(void) { return pin;};
  void printAddress();
  int Reset();
  void Scan(bool Populate);
  OneWire *OWHandle;
};

bool owExists(DeviceAddress addr);
int freeRam ();
extern std::vector<owT> owTs;
extern std::vector<owRH> owRHs;

#endif
