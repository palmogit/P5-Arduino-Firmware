#include "owKam.h"
#include "Streaming.h"
using namespace std;

extern owT *owTs;
extern int NowTs; // number of Tb sensors
extern owRH *owRHs;
extern int NowRHs; // number of Tb sensors


owPin::owPin( int aPin) {
  pin=aPin;
  nSensors=0;
  nTs=0;
  nRHs=0;
  OWHandle=new OneWire((uint8_t) pin);
  Scan(false);
}
owPin::~owPin() {
  delete OWHandle;
}


void owPin::Scan(bool Populate) {
  //  OWHandle->reset();
  OWHandle->Init(pin);
  OWHandle->reset_search();
  for (int i=0; i<8; i++) {
    devAddress[i]=0;
  }
  owRH *powRH=owRHs;
  if (owRHs != NULL) 
    do  { powRH = powRH->next; } while ( powRH->next != NULL);
  owT *powT=owTs;
  if (owTs != NULL) 
    do  { powT = powT->next; } while ( powT->next != NULL);
  while ( OWHandle->search(devAddress)) {
    if (devAddress[0] == 0x26) { //RH
      if (verbose>10) 
	printAddress();
      if (Populate && !owExists(devAddress)) {
	if (owRHs == NULL) {  // very first sensor
	  owRHs = new owRH (pin, OWHandle, devAddress);
	  powRH=owRHs;
	  powRH->next=NULL;
	} else {
	  powRH->next= new  owRH (pin, OWHandle, devAddress);
	  powRH=powRH->next;
	  powRH->next=NULL;
	}
	//	owRHs.push_back(owRH(pin, OWHandle, devAddress));
	nRHs++; nSensors++; NowRHs++;
	if (verbose>10) 
	  Serial << " New" << endl;
      } else 
	if (verbose>10) 
	  Serial << F(" Already Exists") << endl;
    }
    else if (devAddress[0] == 0x28) {  //T
      if (verbose>10) 
	printAddress();
      if (Populate && !owExists(devAddress)) {
	if (owTs == NULL) {  // very first sensor
	  owTs = new owT (pin, OWHandle, devAddress);
	  powT=owTs;
	} else {
	  powT->next= new owT (pin, OWHandle, devAddress);
	  powT=powT->next;
	}
	//	owTs.push_back(owT(pin, OWHandle, devAddress)); 
	nTs++; nSensors++; NowTs++;
	if (verbose>10) 
	  Serial << " New" << endl;
      } else 
	if (verbose>10) 
	  Serial << F(" Already Exists") << endl;
    }
    else {
      if (verbose>10) {
	printAddress();
      }
    }
  }
}

void owPin::printAddress() {
    // zero pad the address if necessary

  Serial << " Pin " << pin;

  if (devAddress[0] == 0x26) {
    Serial.print("  RH/TH ");
  }
  if (devAddress[0] == 0x28) {
    Serial.print(" Tsensor");
  }
  if (devAddress[0] >= 16) {
    Serial.print("(");   Serial.print(devAddress[0], HEX);  Serial.print(") ");
  }   for (uint8_t i = 1; i < 8; i++) {
    if (devAddress[i] < 16) Serial.print("0");
    Serial.print(devAddress[i], HEX);
  }
}

owSensor::owSensor(int apin, OneWire *handle,  DeviceAddress address) {
  pin=apin;
  OWHandle=handle;
  for (int i=0; i<8; i++)
    Address[i]=address[i];
  LastData.tstamp=0;
  LastData.Status=-1;
  PrevData.tstamp=0;
  PrevData.Status=-1;
  // if (address[0] == 0x26 ) 
  //   Type=1;
  // if (address[0] == 0x28 ) 
  //   Type=2;
}

void owSensor::printAddress() {
    // zero pad the address if necessary

  Serial << " Pin " << pin;

  if (Address[0] == 0x26) {
    Serial.print("  RH/TH ");
  }
  if (Address[0] == 0x28) {
    Serial.print(" Tsensor");
  }
  if (Address[0] >= 16) {
    Serial.print("(");   Serial.print(Address[0], HEX);  Serial.print(") ");
  }   for (uint8_t i = 1; i < 8; i++) {
    if (Address[i] < 16) Serial.print("0");
    Serial.print(Address[i], HEX);
  }
}

bool owExists(DeviceAddress addr) {
  owRH *powRH=owRHs;
  owT *powT=owTs;
  if (powRH != NULL) {
    if (addressMatch(powRH->getAddress(),addr,8))
      return true;
    do {
      powRH=powRH->next;
      if (addressMatch(powRH->getAddress(),addr,8))
	return true;
    } while (powRH->next != NULL);
  }
  if (powT != NULL) {
    if (addressMatch(powT->getAddress(),addr,8))
      return true;
    do {
      powT=powT->next;
      if (addressMatch(powT->getAddress(),addr,8))
	return true;
    } while (powT->next != NULL);
  }

  return false;
}

bool addressMatch(uint8_t *a1, uint8_t *a2, int len) {
  for (int i=0; i<len; i++) 
    if (a1[i] != a2[i]) 
      return false;
  return true;
}

int freeRam () {
  extern int __heap_start, *__brkval;
  int v;
  return (int) &v - (__brkval == 0 ? (int) &__heap_start : (int) __brkval);
}

void software_Reset() {
// Restarts program from beginning but 
// does not reset the peripherals and registers
  asm volatile ("  jmp 0");  
}

void PrintMemoryAddress(uint16_t ptr) {
  unsigned char tmp;
  char string[]="0123456789ABCDEF";
  Serial.print(" ");
  tmp = *(1+ (unsigned char*) &ptr); // MSB
  Serial.print( string[tmp >> 4] );
  Serial.print( string[tmp & 0xF] );
  
  tmp = *(0+ (unsigned char*) &ptr); // LSB
  Serial.print( string[tmp >> 4] );
  Serial.print( string[tmp & 0xF] );
  Serial.print(" ");
} 
