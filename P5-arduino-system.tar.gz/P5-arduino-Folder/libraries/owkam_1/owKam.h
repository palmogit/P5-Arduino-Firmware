#ifndef OneKam_h
#define OneKam_h
#include <inttypes.h>
#include <Streaming.h>
#include <OneWire.h>

extern int verbose;
typedef uint8_t DeviceAddress[8];
typedef struct {
  unsigned long tstamp;
  float Th;
  int Status;
} SensorData;

class owSensor {
 protected:
  uint8_t pin;
  DeviceAddress Address;
  SensorData LastData;
  SensorData PrevData;
  OneWire *OWHandle;
 public:
  owSensor(int apin, OneWire *handle,  DeviceAddress address);
  int Print (char *buffer);
  void printAddress();
  uint8_t getAddressByte (int b) { return Address[b]; };
  uint8_t *getAddress () { return Address; };
};

class owT: public owSensor {
 public:
  owT *next;
 owT(int apin, OneWire *handle,  DeviceAddress address) : 
  owSensor(apin, handle, address) {next=NULL;}
};
class owRH: public owSensor {
 public:
  owRH *next; 
 owRH(int apin, OneWire *handle,  DeviceAddress address) : 
  owSensor(apin, handle,  address) {next=NULL; }
};

class owPin {
 private:
  int pin;
  DeviceAddress devAddress;
  
 public:
  int nSensors;
  int nTs;
  int nRHs;
  owPin();
  ~owPin();
  owPin( int aPin);
  int getpin(void) { return pin;};
  void printAddress();
  int Reset();
  void Scan(bool Populate);
  OneWire *OWHandle;
};


bool owExists(DeviceAddress addr);
int freeRam ();
void software_Reset();
void PrintMemoryAddress(uint16_t ptr);
bool addressMatch(uint8_t *a1, uint8_t *a2, int len);

#endif
