#ifndef _ARCH_STRING_H
#define	_ARCH_STRING_H

#include <stdio.h>
#include <assert.h>
#include "stdint.h"

#ifdef	__cplusplus
extern "C" {
#endif

size_t 	_strlen(const char * text);
int	_strcmp(const char *, const char *);
void *	_memcpy(void *, const void *, size_t);
void *	_memset(void *, int, size_t);
char *  _strcpy(char *, const char *);
char *	_strdup(const char *);
char *	_strchr(const char *,int);
char *	_strrchr(const char *,int);

#ifdef	__cplusplus
}
#endif

#endif	/* _STRING_H */

