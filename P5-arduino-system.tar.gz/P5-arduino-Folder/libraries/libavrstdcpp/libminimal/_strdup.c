/*
 * _strdup.c
 *
 * Created: 3/5/2011 12:26:21 PM
 *  Author: admin
 */
#include "_string.h"

char * _strdup(const char * s1)
{
	assert(s1);
	char *	retval = malloc(_strlen(s1)+1);
	_strcpy(retval,s1);

	return retval;
}