

#include "_string.h"

char * _strchr(const char * s1, int c)
{
	while(*s1 != c) {
		if (*(s1++) == NULL)
			return 0;
	}
	return s1;
}

char * _strrchr(const char * s1, int c)
{

	return 0;	
}	