#include "_string.h"

// Returns 0 if equal
int _strcmp(const char * compare_to, const char * compare_from)
{
	register char c1, c2;

	while(1)
	{
		c1 = *compare_to++;
		c2 = *compare_from++;
		
		if (!c1||!c2||c1 != c2)
			break;
	}
	return ((int)c1 - (int)c2);
}

