#include "_string.h"

char * _strcpy(char * dest, const char * src)
{
    char * dptr = dest;
	while(*dptr++ = *src++);
	return dptr;
/*    const char * sptr = src;
    
    while(*sptr++)
        *dptr++ = *sptr;
    *dptr++ = 0;
    
    return dest;
	*/
}
