#ifndef _ARCH_STRING_H_
#define _ARCH_STRING_H_

#include <stdint.h>
#include "_string.h"

#ifdef	__cplusplus
extern "C" {
#endif
    
static inline size_t strlen(const char * text)
{
	return I(strlen(text));
}

static inline void * memset(void*s,int ch,size_t len)
{
	return I(memset(s,ch,len));
}

static inline void * memcpy(void *dest, const void * src, size_t l)
{
	return I(memcpy(dest,src,l));
}

static inline int strcmp(const char *s1,const char *s2)
{
	return I(strcmp(s1,s2));
}

static inline char * strcpy(char * dest, const char * src)
{
    return I(strcpy(dest,src));
}

static inline char * strdup(const char *s1)
{
	return I(strdup(s1));
}

static inline char * strchr(const char * s1, int c)
{
	return I(strchr(s1,c));
}

static inline char * strrchr(const char * s1, int c)
{
	return I(strrchr(s1,c));
}

#ifdef	__cplusplus
}
#endif

#endif
