#include "_string.h"

void * _memcpy(void * dest, const void * src, size_t n)
{
	char * destPtr = dest;
	const char * srcPtr = src;

	while(n--)
		*destPtr++ = *srcPtr++;

	return dest;
}

