#include "_string.h"

// Set len characters of src with ch
void *	_memset(void * src, int ch, size_t len)
{
	char * srcPtr = src;
	
	while(len--) *srcPtr++ = ch;

	return srcPtr;
}
