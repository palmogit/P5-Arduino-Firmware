#include "_string.h"

size_t _strlen(const char * text)
{
    size_t      len = 0;
    
    while( *text++ )
        ++len;
    
    return len;
}
