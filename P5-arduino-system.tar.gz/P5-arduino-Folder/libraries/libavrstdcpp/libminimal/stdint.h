

#ifndef STDINT_H
#define	STDINT_H

#ifdef	__cplusplus
extern "C" {
#endif

typedef unsigned char   uint8_t;
typedef unsigned short  uint16_t;
typedef unsigned int    uint32_t;
typedef signed char     int8_t;
typedef signed short    int16_t;
typedef signed int      int32_t;

typedef unsigned int    size_t;
typedef unsigned long   time_t;
    
typedef uint8_t		uint8;
typedef uint16_t	uint16;
typedef uint32_t	uint32;
typedef unsigned char   byte;
typedef unsigned short  word;

typedef unsigned char    uchar;


#ifdef	__cplusplus
}
#endif

#endif	/* STDINT_H */

