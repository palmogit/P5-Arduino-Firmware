#ifndef XMEGAOS_RTC
#define XMEGAOS_RTC

#if defined(XMEGA_DEFINED)

#include "common.h"
//#include <avr/iox256a3.h>
//#include "list.h"

namespace rtc
{
#define IsBusy()         (RTC32.SYNCCTRL & RTC32_SYNCBUSY_bm);
#define ToscBusy()      (VBAT.STATUS & VBAT_XOSCRDY_bm)
#define SyncCnt()       (RTC32.SYNCCTRL |= RTC32+SYNCCNT_bm)
#define GetOvlFflag()   (RTC32.INITFLAGS & RTC32_OVFIF_bm)
#define GetCmpFLag()    (RTC32.INITFLAGS & RTC32_COMPIE_bm)
#define GetPeriod()     (RTC32.PER)

#define SetCompVal(_val)    (RTC32.COMP = (_val))

}

typedef struct
{
    uint16_t year;
    uint8_t  month;
    uint8_t  day;
    uint8_t  hour;
    uint8_t  min;
    uint8_t  sec;

} display_time_t;


         /// Realtime clock
class rtc_t
{
public:
    rtc_t();
    ~rtc_t();

    RTC_t *  RTCT() { return &RTC; }
    RTC_t *  CLOCKS(uint8 numclocks = 0) {
        if (numclocks)  numclocks = (++numclocks); 
        else numclocks = (--numclocks);
        }
    // RTC_t struct
    // register8 CTRL, STATUS, INTCTRL, INTFLAGS, TEMP, byte_resvd5, byte_resvd6, byte_resv7
  
private:

    RTC_t   *          rtc;
    RTC_t **     rtc_clocks;
    uint8               clocks;
    RTC_PRESCALER_t*    rtc_prescale;
    RTC_COMPINTLVL_t *  rtc_compintlvl;
    RTC_OVFINTLVL_t *   rtc_ovfintlvl;
};

#endif
#endif