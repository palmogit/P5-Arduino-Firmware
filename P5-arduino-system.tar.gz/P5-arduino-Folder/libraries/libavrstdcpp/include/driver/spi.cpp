/*******************************************************************************
** Name: spi.cpp                                                             **
** Description: The Serial Peripheral Interface Bus implementation           **
**                                                                           **
** Open Source Initiative (OSI) Approved License                             **
**                                                                           **
**  Copyright (c) 2009-2010 Barry "Gian" James  <bjames@munixos.net>         **
**  All rights reserved.                                                     **
**                                                                           **
**  Redistribution and use in source and binary forms, with or without       **
**  modification, are permitted provided that the following conditions are   **
**  met:                                                                     **
**                                                                           **
**  * Redistributions of source code must retain the above copyright notice, **
**    this list of conditions and the following disclaimer.                  **
**  * Redistributions in binary form must reproduce the above copyright      **
**    notice, this list of conditions and the following disclaimer in the    **
**    documentation and/or other materials provided with the distribution.   **
**                                                                           **
**  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS      **
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED **
** TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A           **
** PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT        **
** HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    **
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  **
** TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    **
** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    **
** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      **
** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        **
** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              **
**                                                                           **
******************************************************************************/
// $Id: spi.cpp 56499 2011-03-14 15:25:03Z unknown $
// $Id: spi.cpp 56499 2011-03-14 15:25:03Z unknown $

#include "spi.h"


#ifdef XMEGA_DEFINED
SPI::SPI( SPI_t * s, uint8_t i /*= 0*/, BusMode m /*= BusMode::Master*/ )
: Bus(i,BusType::SPI,m)
{
	spi = s;
}
#endif


SPI::SPI(uint8 i, BusMode m)
: Bus(i,BusType::SPI,m)
{

}


bool
SPI::IsConfigured()
{
    return (datain != NULL && dataout != NULL && select != NULL && clock != NULL);
}

bool
SPI::Connect()
{
    if (!IsConfigured()) return false;
    if (mode == BusMode::Master)
    {
#if defined(SPCR)
        BCLR(SPCR,SPE);
        BSET(*select->DDR(),select->Pin());
        ReleaseSlave();

        BSET(SPCR, MSTR);   // set as master
        BSET(SPCR, SPE);    // enable SPI
#elif XMEGA_DEFINED
        BCLR(SPIC_CTRL,SPI_ENABLE_bp);
        BSET(*select->DDR(),select->Pin());
        ReleaseSlave();

        BSET(SPIC_CTRL, SPI_MASTER_bp);
        BSET(SPIC_CTRL, SPI_ENABLE_bp);
// Gotta use USART in SPI mode for ATtiny2313
#elif defined(__AVR_ATtiny2313__)

#endif
        // setup pins for OUTPUT
        BSET(*dataout->DDR(),dataout->Pin());    // MOSI
        BSET(*clock->DDR(), clock->Pin());       // SCK
        BSET(*select->DDR(), select->Pin());     // SS
    } else {
        BSET(*datain->DDR(), datain->Pin());
#if XMEGA_DEFINED
        BSET(SPIC_CTRL, SPI_ENABLE_bp);
        BCLR(SPIC_CTRL, SPI_MASTER_bp);
#elif defined(SPCR)
        BSET(SPCR, SPE);
#else

#endif
    }
    return true;
}

char
SPI::TxRx(volatile char c)
{
    SPDR = c;
    while( !(SPSR & (1<<SPIF))) ;
    return SPDR;
#if defined(__AVR_ATmega2313__)
 volatile asm("ldi r16,c\n"
     "SPITransfer:\n"
     "out\tUSIDR,r16\n"
     "ldi\tr16,(1<<USIOIF)\n"
     "out\tUSISR,r16\n"
     "ldi\tr16,(1<<USIWM0)|(1<<USICS1)|(1<<USICLK)|(1<<USITC)\n"
     "SPITransferLoop:\t\n"
     "out\tUSICR,r16\n"
     "sbis\tUSISR,USIOIF\n"
     "rjmp\tSPITransferLoop\n"
     "in\tr16,USIDR"
     "ret r16");
#endif
}

void
SPI::SendByte(uint8 remote, char byte)
{
    SPDR = byte;
    while ( !(SPSR & (1<<SPIF)));
}

void
SPI::SendWord(uint8 remote, wchar_t word)
{
    SendByte(remote,word);
    SendByte(remote,(word&0xFF00));
}

char
SPI::RecvByte()
{
    while( !(SPSR & (1<<SPIF)));
    return SPDR;
}

wchar_t
SPI::RecvWord()
{
    wchar_t wc = RecvByte();
    wc <<= 8;
    wc = RecvByte();
    return wc;
}

