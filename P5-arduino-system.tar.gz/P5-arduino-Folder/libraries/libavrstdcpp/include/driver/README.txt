$Id$
libavrstdc++/driver
README

The peripheral drivers in this directory are for ATtiny* and ATmega* MCUs.
The xmega/ subdirectory contains drivers for ATxmega MCUs while the
ext/ subdirectory contains drivers for commonly used/found external
device peripherals like AT45* DataFlash chips, EEPROMS, 4470 LCD, etc.

Following the conventions in this library (which follows the conventions
in the BOOST C++ library), everything in these directories are header-only
C++ headers, meaning there is no separate compile for different MCUs. To
use these drivers you can either
	a) copy the desired driver file into your project's directory and use
	   it as a standard local include (eg #include "usart")
	b) install all the drivers as normal when installing the top-level
	   libavrstdc++ STL library and reference them with system includes
	   (eg #include <avrstdcpp/driver/usart>).

If you have any driver to contribute or would like to see a driver developed
for a particular device, let us know by sending us email or leaving a post
on the community forums. All ways to contact us is listed in the top-level
README file.


