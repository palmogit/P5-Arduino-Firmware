#ifndef _MUNIX_TWI_H_
#define	_MUNIX_TWI_H_
/******************************************************************************
 ** Name: twi.h                                                    **
 ** Description: Declaration of filesystem paths.                             **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 **  Copyright (c) 2009-2010 Barry "Gian" James  <bjames@munixos.net>         **
 **  All rights reserved.                                                     **
 **                                                                           **
 **  Redistribution and use in source and binary forms, with or without       **
 **  modification, are permitted provided that the following conditions are   **
 **  met:                                                                     **
 **                                                                           **
 **  * Redistributions of source code must retain the above copyright notice, **
 **    this list of conditions and the following disclaimer.                  **
 **  * Redistributions in binary form must reproduce the above copyright      **
 **    notice, this list of conditions and the following disclaimer in the    **
 **    documentation and/or other materials provided with the distribution.   **
 **                                                                           **
 **  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS      **
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED **
 ** TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A           **
 ** PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT        **
 ** HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    **
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  **
 ** TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    **
 ** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    **
 ** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      **
 ** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        **
 ** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              **
 **                                                                           **
 ******************************************************************************/
#define _MUNIX_TWI_H_ID "$Id: twi.h 55956 2011-02-25 05:05:11Z unknown $"
// Last Modified $DateTime$ by $Author: unknown $
#include <util/twi.h>
#include "common.h"
#include "bus.h"

#define DEFAULT_TWI_SPEED   400

class TWI : public Bus
{
public:
    TWI(uint8 i = 0, BusMode m = BusMode::Master);

    // implemented pure-virtual functions
    bool    Connect();
    void    SendByte(uint8 remote, char byte);
    void    SendWord(uint8 remote, wchar_t word);
    char    RecvByte();
    wchar_t RecvWord();
    void    PowerUp() { power_twi_enable(); }
    void    PowerDown() { power_twi_disable(); }

    inline void     StartCondition() { TWCR = ((1<<TWINT)|(1<<TWSTA)|(1<<TWEN)); }
    inline bool     StartOK() { return (TW_STATUS == TW_START); }
    inline bool     AddrOK() { return (TW_STATUS == TW_MT_SLA_ACK); }
    inline bool     DataOK() { return (TW_STATUS == TW_MT_DATA_ACK); }
    inline void     StopCondition() { TWCR = ((1<<TWINT)|(1<<TWEN)|(1<<TWSTO)); }
    inline void     WaitFlag() { while( !(TWCR & (1<<TWINT)) ); }

    void    Prescaler(uint8);
    void    Bitrate(uint8 b) { BSET(TWBR,b); }

private:
    int     wireSpeed;      // kHz
};

#endif	/* _MUNIX_TWI_H_ */

