#ifndef _LIBDEV_AT25DF_H_
#define _LIBDEV_AT25DF_H_
/*******************************************************************************
 ** Name: at25df.h                                                            **
 ** Description: The body of the common settings/parameters file.             **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 ** The contents of this file are subject to the terms of the                 **
 ** Common Development and Distribution License, Version 1.0 only             **
 ** (the "License").  You may not use this file except in compliance          **
 ** with the License.                                                         **
 **                                                                           **
 ** You can find a copy of the license in the license.txt within              **
 ** this distribution or at http://www.munixos.net/licensing.                 **
 ** Software distributed under the License is distributed on an "AS IS"       **
 ** basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.           **
 ** See the License for the specific language governing permissions           **
 ** and limitations under the License.                                        **
 **                                                                           **
 ** When distributing Covered Code, include this CDDL header in each          **
 ** file and include the License file at $HOME/license.txt.                   **
 ** If applicable, add the following below this header, with the indicated    **
 ** fields enclosed by brackets "[]" replaced with your own identifying       **
 ** information: Portions Copyright [yyyy] [name of copyright owner]          **
 **                                                                           **
 **                                                                           **
 ** Copyright (c) 2009-2010  Barry Gian James.                                **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Ref: $HeadURL: https://munix.svn.codeplex.com/svn/trunk/asmu/assembler.cpp $
 ******************************************************************************/
// $Id: assembler.cpp 55956 2011-02-25 09:08:34Z bjames $

// SPI Instruction Set
#define WREN    0x06    // Write enable
#define WRDEN   0x04    // Write disable
#define RDSR    0x05    // Read status register
#define WRSR    0x01    // Write status register
#define WRSR2   0x31    // write status register byte 2
#define SECLKDN 0x33    // sector lockdown
#define FRSEC   0x34    // freeze sector lockdown state
#define RDSECLK 0x35    // read sector lockdown registers
#define PGOTP   0x9B    // program OTP security register
#define RDPGOTP 0x77    // read OTP security register
#define PROTSEC 0x36    // protect sector
#define UPROTSEC 0x39   // unprotec sector
#define RD      0x03    // Read data
#define FRD     0x0B    // fast read
#define FRDO    0x3B    // fast read dual output
#define RSPR    0x3C    // read sector protection register
#define PGPGM   0x02    // page program
#define BLKER   0xD8    // block erase 64k
#define BLKER2  0x52    // block erase 32k
#define SECER   0x20    // sector erase 4k
#define CHER    0xC7    // chip erase
#define PWRD    0xB9    // power down
#define PWRU    0xAB    // release power down
#define DEVID   0xAB    // device ID
#define MFGID   0x90    // manufacturer ID
#define JEDID   0x9F    // JEDEC ID
#define RESET   0xF0    // reset
#define DPWRD   0xB9    // deep power down
#define RDPWRD  0xAB    // resume from deep power down



#endif
