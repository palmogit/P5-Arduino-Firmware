/*******************************************************************************
 ** Name: s25fl064.h                                                          **
 ** Description: The body of the common settings/parameters file.             **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 ** The contents of this file are subject to the terms of the                 **
 ** Common Development and Distribution License, Version 1.0 only             **
 ** (the "License").  You may not use this file except in compliance          **
 ** with the License.                                                         **
 **                                                                           **
 ** You can find a copy of the license in the license.txt within              **
 ** this distribution or at http://www.munixos.net/licensing.                 **
 ** Software distributed under the License is distributed on an "AS IS"       **
 ** basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.           **
 ** See the License for the specific language governing permissions           **
 ** and limitations under the License.                                        **
 **                                                                           **
 ** When distributing Covered Code, include this CDDL header in each          **
 ** file and include the License file at $HOME/license.txt.                   **
 ** If applicable, add the following below this header, with the indicated    **
 ** fields enclosed by brackets "[]" replaced with your own identifying       **
 ** information: Portions Copyright [yyyy] [name of copyright owner]          **
 **                                                                           **
 **                                                                           **
 ** Copyright (c) 2009-2010  Barry Gian James.                                **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Ref: $HeadURL: $
 ******************************************************************************/
// Portions Copyright 2011 OpenHouseware, LLC.

// $Id: s25fl064.h 55956 2011-02-25 09:08:34Z bjames $



#ifndef _LIBDEV_S25FL064_H_
#define _LIBDEV_S25FL064_H_

#include "device.h"

enum class S25FL064_SPI
{
	RD=0x03,			// Read
	FRDIO=0xBB,			// Fast Read I/O
	FRDO=0x3B,			// Fast Read Output
	HSRD=0x0B,			// High Speed Read
	SERASE=0x20,		// Sector erase
	ER32K=0x52,			// Erase 32k block
	ER64K=0xD8,			// Erase 64k block
	CHPERASE=0x60,
	PGPGM=0x02,
	DIPGPGM=0xA2,		// Dual input page program
	RDSR=0x05,
	EWSR=0x50,
	WRSR=0x01,
	WREN=0x06,
	WRDI=0x04,
	RDID=0x90,			// Read ID
	JEDECID=0x9F,
	EHLD=0xAA,			// Enable !HOLD
	RSID=0x88,			// Read SID
	PSID=0xA5,			// Program SID
	LSID=0x85			// Lockout SID
};

#define S25FL064_PAGE	256
#define S25FL064_SECTOR	4098	// erasable sectors
#define S25FL064_BLOCK 32768	// overlay blocks
#define S25FL064_EBLOCK 65536	// overlay erasable blocks

#define S25FL064_LOWEND	0x000000
#define S25FL064_HIGHEND 0x7FFFFF

#define JEDEC_MFGR_ID	0xBF
#define JEDEC_MEM_TYPE	0x25
#define JEDEC_MEM_CAP	0x4B

#define S25FL064_VOLTAGE	3
#define S25FL064_TPRDWR		100	// 100us from Vdd before you can rd/wr device

class S25FL064 : public Device
{
public:
	S25FL064();


};

#endif /* _LIBDEV_S25FL064_H_ */
