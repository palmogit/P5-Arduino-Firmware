/*******************************************************************************
 **  Name: s25fl064.cpp                                                       **
 **  Description:                                                             **
 **                                                                           **
 **  CDDL: Open Source Initiative (OSI) Approved License                      **
 **                                                                           **
 **  The contents of this file are subject to the terms of the CDDL:          **
 **  Common Development and Distribution License (the "License").             **
 **  You may not use this file except in compliance with the License.         **
 **                                                                           **
 **  You can obtain a copy of the license at $PROJECT_ROOT/LICENSE            **
 **  or http://www.opensolaris.org/os/licensing.  This code is Open Source    **
 **  and you are free to use it within the confines of the license, even      **
 **  for your own closed-source commercial projects, as long as you follow    **
 **  the terms set forth in the CDDL.                                         **
 **                                                                           **
 **  When distributing Covered Code, include this CDDL HEADER in each         **
 **  file and include the License file at $PROJECT_ROOT/LICENSE.              **
 **  If applicable, add the following below this CDDL HEADER, with the        **
 **  fields enclosed by brackets "[]" replaced with your own identifying      **
 **  information: Portions Copyright [yyyy] [name of copyright owner]         **
 **                                                                           **
 **  Copyright (c) 2009-2010 Barry "Gian" James  <bjames@unix-arm.org>        **
 **  All rights reserved.                                                     **
 **  Copyright (c) 2011 OpenHousewares, LLC <open@OpenHousewares.com>         **
 **  All rights reserved.                                                     **
 ******************************************************************************/
// $Id: w25x.cpp 56176 2011-03-03 03:40:53Z bjames $
// Created on February 25, 2011, 4:20 AM
// Modified $Date: 2011-03-02 20:40:53 -0700 (Wed, 02 Mar 2011) $ by $Author: bjames $

#include "s25fl064.h"

S25FL064::S25FL064()
: Device(DeviceType::Page, DeviceFamily::Memory, "/dev/flash/s25fl064")
{


}