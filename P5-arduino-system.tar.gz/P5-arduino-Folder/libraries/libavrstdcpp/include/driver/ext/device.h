#ifndef _MUNIX_DEVICE_H_
#define _MUNIX_DEVICE_H_

/*******************************************************************************
 ** Name: device.h                                                            **
 ** Description:              **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 ** The contents of this file are subject to the terms of the                 **
 ** Common Development and Distribution License, Version 1.0 only             **
 ** (the "License").  You may not use this file except in compliance          **
 ** with the License.                                                         **
 **                                                                           **
 ** You can find a copy of the license in the license.txt within              **
 ** this distribution or at http://www.munixos.net/licensing.                 **
 ** Software distributed under the License is distributed on an "AS IS"       **
 ** basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.           **
 ** See the License for the specific language governing permissions           **
 ** and limitations under the License.                                        **
 **                                                                           **
 ** When distributing Covered Code, include this CDDL header in each          **
 ** file and include the License file at $HOME/license.txt.                   **
 ** If applicable, add the following below this header, with the indicated    **
 ** fields enclosed by brackets "[]" replaced with your own identifying       **
 ** information: Portions Copyright [yyyy] [name of copyright owner]          **
 **                                                                           **
 **                                                                           **
 ** Copyright (c) 2009-2010  Barry Gian James.                                **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Ref: $HeadURL$
 ******************************************************************************/
// Portions (c) 2011-12 Open Design Strategies, LLC.
#define MUNIX_DEVICE_H_ID "$Id$"
// Last Modified $DateTime: 2010/02/12 01:42:30 $ by $Author$

// The Device class describes devices that are used/found in the munix system.
// These objects elucidate and enumerate the interfaces for devices of their
// clade.  They do not provide drivers for a particular device.  The drivers
// are sub-classed/derived from kernel factors (drivers) in <munixos/dev.h>


#include "common.h"
#include "path.h"

enum class DeviceFamily { USB, Memory, Network, Video, Sound, GenericSPI, GenericTWI, System };
enum class DeviceType { Character, Block, Frame, Sector, Page, Volume };

class	Device
{
public:
    Device(const DeviceType t, const DeviceFamily f, const char * p);
    virtual ~Device();

	// Getters
    const DeviceType		GetType() const{ return type_; }
	const DeviceFamily	GetFamily() const { return family_; }
	const DirectoryPath *	GetPath() const { return path_; }
	const uint8_t			GetID() const { return id_; }


protected:
	DeviceType		type_;
    DeviceFamily    family_
    DirectoryPath * path_;
	uint8_t			id_;

	static uint8_t	sid;
	static uint8_t	count;
	static uint8_t	incr() { return ++sid; }
	static void		incr_count() {  ++count; }
	static void		decr_count() {  --count; }
};


#endif	/* _MUNIX_DEVICE_H_ */
