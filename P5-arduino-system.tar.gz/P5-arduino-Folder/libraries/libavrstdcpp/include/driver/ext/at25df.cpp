/*******************************************************************************
 **  Name: at25df.cpp                                                        **
 **  Description:                                                             **
 **                                                                           **
 **  CDDL: Open Source Initiative (OSI) Approved License                      **
 **                                                                           **
 **  The contents of this file are subject to the terms of the CDDL:          **
 **  Common Development and Distribution License (the "License").             **
 **  You may not use this file except in compliance with the License.         **
 **                                                                           **
 **  You can obtain a copy of the license at $PROJECT_ROOT/LICENSE            **
 **  or http://www.opensolaris.org/os/licensing.  This code is Open Source    **
 **  and you are free to use it within the confines of the license, even      **
 **  for your own closed-source commercial projects, as long as you follow    **
 **  the terms set forth in the CDDL.                                         **
 **                                                                           **
 **  When distributing Covered Code, include this CDDL HEADER in each         **
 **  file and include the License file at $PROJECT_ROOT/LICENSE.              **
 **  If applicable, add the following below this CDDL HEADER, with the        **
 **  fields enclosed by brackets "[]" replaced with your own identifying      **
 **  information: Portions Copyright [yyyy] [name of copyright owner]         **
 **                                                                           **
 **  Copyright (c) 2009-2010 Barry "Gian" James  <bjames@unix-arm.net>        **
 **  All rights reserved.                                                     **
 **  Copyright (c) 2011 OpenHousewares, LLC <open@OpenHousewares.com>         **
 **  All rights reserved.                                                     **
 ******************************************************************************/
// $Id$
// Created on February 25, 2011, 4:18 AM
// Modified $Date$ by $Author$

#include "at25df.h"
