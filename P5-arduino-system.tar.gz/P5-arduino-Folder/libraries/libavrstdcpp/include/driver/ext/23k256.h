#ifndef _LIBDEV_25K256_H_
#define _LIBDEV_25K256_H_
/*******************************************************************************
 ** Name: 23k256.h                                                            **
 ** Description:              **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 ** The contents of this file are subject to the terms of the                 **
 ** Common Development and Distribution License, Version 1.0 only             **
 ** (the "License").  You may not use this file except in compliance          **
 ** with the License.                                                         **
 **                                                                           **
 ** You can find a copy of the license in the license.txt within              **
 ** this distribution or at http://www.munixos.net/licensing.                 **
 ** Software distributed under the License is distributed on an "AS IS"       **
 ** basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.           **
 ** See the License for the specific language governing permissions           **
 ** and limitations under the License.                                        **
 **                                                                           **
 ** When distributing Covered Code, include this CDDL header in each          **
 ** file and include the License file at $HOME/license.txt.                   **
 ** If applicable, add the following below this header, with the indicated    **
 ** fields enclosed by brackets "[]" replaced with your own identifying       **
 ** information: Portions Copyright [yyyy] [name of copyright owner]          **
 **                                                                           **
 **                                                                           **
 ** Copyright (c) 2009-2010  Barry Gian James.                                **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Ref: $HeadURL$
 ******************************************************************************/
#define MUNIX_23K256_H_ID "$Id$"
// Last Modified $DateTime: 2010/02/12 01:42:30 $ by $Author$

// This is the SRAM used in munix by the AMPS.

#define SRAM_23K256_VOLTAGE	3

// Instruction set
enum class SRAM_25K256
{
	RD=0x03,
	WR=0x02,
	RDSR=0x05,
	WRSR=0x01
};

#define SRAM_23K256_LOWEND	0x0000
#define SRAM_23K256_HIGHEND	0x7FFF


class SRAM_23K256 : public Device
{
public:
	SRAM_23K256();
};


#endif /* 25K256_H_ */