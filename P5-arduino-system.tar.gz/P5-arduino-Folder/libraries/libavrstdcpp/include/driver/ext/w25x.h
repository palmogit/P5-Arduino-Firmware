#ifndef _LIBDEV_W25X_H_
#define _LIBDEV_W25X_H_
/*******************************************************************************
 ** Name: w25x.h                                                              **
 ** Description: The body of the common settings/parameters file.             **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 ** The contents of this file are subject to the terms of the                 **
 ** Common Development and Distribution License, Version 1.0 only             **
 ** (the "License").  You may not use this file except in compliance          **
 ** with the License.                                                         **
 **                                                                           **
 ** You can find a copy of the license in the license.txt within              **
 ** this distribution or at http://www.munixos.net/licensing.                 **
 ** Software distributed under the License is distributed on an "AS IS"       **
 ** basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.           **
 ** See the License for the specific language governing permissions           **
 ** and limitations under the License.                                        **
 **                                                                           **
 ** When distributing Covered Code, include this CDDL header in each          **
 ** file and include the License file at $HOME/license.txt.                   **
 ** If applicable, add the following below this header, with the indicated    **
 ** fields enclosed by brackets "[]" replaced with your own identifying       **
 ** information: Portions Copyright [yyyy] [name of copyright owner]          **
 **                                                                           **
 **                                                                           **
 ** Copyright (c) 2009-2010  Barry Gian James.                                **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Ref: $HeadURL: https://munix.svn.codeplex.com/svn/trunk/asmu/assembler.cpp $
 ******************************************************************************/
// $Id: assembler.cpp 55956 2011-02-25 09:08:34Z bjames $


// SPI Instruction Set
#define WRSR    0x01    // Write status register
#define PGPGM   0x02    // page program
#define RD      0x03    // Read data
#define WRDEN   0x04    // Write disable
#define RDSR    0x05    // Read status register
#define WREN    0x06    // Write enable
#define FRD     0x0B    // fast read
#define SECER   0x20    // sector erase
#define FRDO    0x3B    // fast read dual output
#define JEDID   0x9F    // JEDEC ID
#define MFGID   0x90    // manufacturer ID
#define PWRU    0xAB    // release power down
#define DEVID   0xAB    // device ID
#define PWRD    0xB9    // power down
#define CHER    0xC7    // chip erase
#define BLKER   0xD8    // block erase

#define x25_CS      1
#define x25_MISO    2
#define x25_WP      3
#define x25_GND     4
#define x25_MOSI    5
#define x25_SCK     6
#define x25_HOLD    7
#define x25_VCC     8

#define x25_RAMHIGH 0x3FFFFF
#define x25_RAMLOW  0x000000

#include "device.h"

class W25X : public Device
{
public:
	W25X();
};

#endif
