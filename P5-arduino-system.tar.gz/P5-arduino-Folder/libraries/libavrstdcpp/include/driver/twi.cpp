/*******************************************************************************
 ** Name: twi.cpp                                                             **
 ** Description: Two-Wire Interface (I2C)                                     **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 **  Copyright (c) 2009-2010 Barry "Gian" James  <bjames@munixos.net>         **
 **  All rights reserved.                                                     **
 **                                                                           **
 **  Redistribution and use in source and binary forms, with or without       **
 **  modification, are permitted provided that the following conditions are   **
 **  met:                                                                     **
 **                                                                           **
 **  * Redistributions of source code must retain the above copyright notice, **
 **    this list of conditions and the following disclaimer.                  **
 **  * Redistributions in binary form must reproduce the above copyright      **
 **    notice, this list of conditions and the following disclaimer in the    **
 **    documentation and/or other materials provided with the distribution.   **
 **                                                                           **
 **  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS      **
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED **
 ** TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A           **
 ** PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT        **
 ** HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    **
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  **
 ** TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    **
 ** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    **
 ** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      **
 ** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        **
 ** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              **
 **                                                                           **
 ******************************************************************************/
#define _MUNIX_TWI_CPP_ID "$Id: twi.cpp 55956 2011-02-25 05:05:11Z unknown $"
// Last Modified $DateTime$ by $Author: unknown $

#include <util/twi.h>
#include "twi.h"


TWI::TWI(uint8 i, BusMode m)
: Bus(i,BusType::TWI,m)
{
    wireSpeed = DEFAULT_TWI_SPEED;
}

void
TWI::Prescaler(uint8 p)
{
    switch(p)
    {
    case 1:
        TWSR &= ~((1<<TWPS1)|(1<<TWPS0));
        break;
    case 4:
        TWSR |= ((1<<TWPS0));
        break;
    case 16:
        TWSR |= (1<<TWPS1);
        break;
    case 64:
        TWSR |= ((1<<TWPS0)|(1<<TWPS1));
        break;
    }
}


bool
TWI::Connect()
{
    BSET(TWCR,TWIE);


    return true;
}

void
TWI::SendByte(uint8 remote, char byte)
{
    //BSET(remote,TW_WRITE);
    StartCondition();
    WaitFlag();
    TWDR = remote;
    TWCR = ((1<<TWINT)|(1<<TWEN));
    WaitFlag();
    TWDR = byte;
    TWCR = ((1<<TWINT)|(1<<TWEN));
    WaitFlag();
    StopCondition();
}
void
TWI::SendWord(uint8 remote, wchar_t word)
{
    //BSET(remote,TW_WRITE);
    StartCondition();
    WaitFlag();
    TWDR = remote;
    TWCR = ((1<<TWINT)|(1<<TWEN));
    WaitFlag();
    TWDR = (word>>8);
    TWCR = ((1<<TWINT)|(1<<TWEN));
    WaitFlag();
    StartCondition();
    WaitFlag();
    TWDR = remote;
    TWCR = ((1<<TWINT)|(1<<TWEN));
    WaitFlag();
    TWDR = word;
    TWCR = ((1<<TWINT)|(1<<TWEN));
    WaitFlag();
    StopCondition();
}

// TODO
char
TWI::RecvByte()
{
    return 'z';
}

wchar_t
TWI::RecvWord()
{
    return 'z';
}


