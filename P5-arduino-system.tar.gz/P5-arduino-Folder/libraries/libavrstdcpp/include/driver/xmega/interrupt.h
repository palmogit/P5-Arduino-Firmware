#ifndef _MUNIX_INTERRUPT_H
#define	_MUNIX_INTERRUPT_H
/*******************************************************************************
 ** Name: interrupt.h                                                         **
 ** Description:              **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 ** The contents of this file are subject to the terms of the                 **
 ** Common Development and Distribution License, Version 1.0 only             **
 ** (the "License").  You may not use this file except in compliance          **
 ** with the License.                                                         **
 **                                                                           **
 ** You can find a copy of the license in the license.txt within              **
 ** this distribution or at http://www.munixos.net/licensing.                 **
 ** Software distributed under the License is distributed on an "AS IS"       **
 ** basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.           **
 ** See the License for the specific language governing permissions           **
 ** and limitations under the License.                                        **
 **                                                                           **
 ** When distributing Covered Code, include this CDDL header in each          **
 ** file and include the License file at $HOME/license.txt.                   **
 ** If applicable, add the following below this header, with the indicated    **
 ** fields enclosed by brackets "[]" replaced with your own identifying       **
 ** information: Portions Copyright [yyyy] [name of copyright owner]          **
 **                                                                           **
 **                                                                           **
 ** Copyright (c) 2009-2010  Barry Gian James <bjames@munixos.net>            **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Ref: $HeadURL: https://munix.svn.codeplex.com/svn/trunk/libmunix/interrupt.h $
 ******************************************************************************/
// Portions (C) 2011 OpenHouseware, LLC.
// All Rights Reserved

// $Id: interrupt.h 56282 2011-03-05 22:38:01Z unknown $
// Last Modified $DateTime$ by $Author: unknown $
#include "common.h"

enum class InterruptVector {
#if defined(__AVR_ATmega644P__) || defined(__AVR_ATmega324P__) || defined(__AVR_ATmega164P__)

    RESET=0x0000, INT0=0x0002, INT1=0x0004, INT2=0x0006,
    PCINT0=0x0008, PCINT1=0x000A, PCINT2=0x000C, PCINT3=0x000E,
    WDT=0x0010, TIMER2COMPA=0x0012, TIMER2COMPB=0x0014, TIMER2OVF=0x0016,
    TIMER1CAPT=0x0018, TIMER1COMPA=0x001A, TIMER1COMPB=0x001C, TIMER1OVF=0x001E,
    TIMER0COMPA=0x0020, TIMER0COMPB=0x0022, TIMER0OVF=0x0024, SPISTC=0x0026,
    USART0RX=0x0028, USART0UDRE=0x002A, USART0TX=0x002C, ANALOGCMP=0x002E,
    ADC=0x0030, EERDY=0x0032, TWI=0x0034, SPMRDY=0x0036, USART1RX=0x0038,
    USART1UDRE=0x003A, USART1TX=0x003C


#elif defined(__AVR_ATxmega256A3__) || defined(__AVR_ATxmega256A3B__) \
    || defined(__AVR_ATxmega128A3__)

    RESET=0x0000, OSCF=0x0002, PORTC=0x0004,
    PORTR=0x0008, DMA=0x000C, RTC=0x0014, TWIC=0x0018,
    TCC0=0x001C, TCC1=0x0028, SPIC=0x0030, USARTC0=0x0032,
    USARTC1=0x003D, AES=0x003E, NVM=0x0040, PORTB=0x0044,
    ACB=0x0048, ADCB=0x04E, PORTE=0x0056, TWIE=0x005A,
    TCE0=0x05E, TCE1=0x006A, SPIE=0x0072, USARTE0=0x0074, USARTE1=0x007A,
    PORTD=0x0080, PORTA=0x0084, ACA=0x0088, ADCA=0x008E, TCD0=0x009A,
    TCD1=0x00A6, SPID=0x00AE, USARTD0=0x00B0, USARTD1=0x00B6, PORTF=0x0D0,
    TCF=0x00D8, USARTF0=0x00EE

// TODO: everything below in the #elif is just copy/paste. must make real ones.
#elif defined(__AVR_ATxmega64A3__) || defined(__AVR_ATxmega32A3)

    RESET=0x0000, INT0=0x0002, INT1=0x0004, INT2=0x0006,
    PCINT0=0x0008, PCINT1=0x000A, PCINT2=0x000C, PCINT3=0x000E,
    WDT=0x0010, TIMER2COMPA=0x0012, TIMER2COMPB=0x0014, TIMER2OVF=0x0016,
    TIMER1CAPT=0x0018, TIMER1COMPA=0x001A, TIMER1COMPB=0x001C, TIMER1OVF=0x001E,
    TIMER0COMPA=0x0020, TIMER0COMPB=0x0022, TIMER0OVF=0x0024, SPISTC=0x0026,
    USART0RX=0x0028, USART0UDRE=0x002A, USART0TX=0x002C, ANALOGCMP=0x002E,
    ADC=0x0030, EERDY=0x0032, TWI=0x0034, SPMRDY=0x0036, USART1RX=0x0038,
    USART1UDRE=0x003A, USART1TX=0x003C

#endif

};


#endif	/* _MUNIX_INTERRUPT_H */

