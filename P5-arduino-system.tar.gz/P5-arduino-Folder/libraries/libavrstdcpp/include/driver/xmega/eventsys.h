#ifndef _MUNIX_EVENTSYS_H
#define	_MUNIX_EVENTSYS_H
/******************************************************************************
 ** Name: eventsys.h                                                    **
 ** Description: Declaration of filesystem paths.                             **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 **  Copyright (c) 2009-2010 Barry "Gian" James  <bjames@munixos.net>         **
 **  All rights reserved.                                                     **
 **                                                                           **
 **  Redistribution and use in source and binary forms, with or without       **
 **  modification, are permitted provided that the following conditions are   **
 **  met:                                                                     **
 **                                                                           **
 **  * Redistributions of source code must retain the above copyright notice, **
 **    this list of conditions and the following disclaimer.                  **
 **  * Redistributions in binary form must reproduce the above copyright      **
 **    notice, this list of conditions and the following disclaimer in the    **
 **    documentation and/or other materials provided with the distribution.   **
 **                                                                           **
 **  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS      **
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED **
 ** TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A           **
 ** PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT        **
 ** HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    **
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  **
 ** TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    **
 ** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    **
 ** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      **
 ** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        **
 ** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              **
 **                                                                           **
 ******************************************************************************/
// Modified $DateTime$ by $Author: unknown $
#define _MUNIX_EVENTSYS_H_ID "$Id: eventsys.h 55956 2011-02-25 09:08:34Z unknown $"



#include "common.h"

#if XMEGA_DEFINED

enum class EventType : uint8 { Signal, Data };
enum class EventClass : uint8 { Consumer=0x01, Producer=0x02 };

class   EventRouter
{
public:
    EventRouter() = delete;
    EventRouter(const EventRouter &) = delete;
    ~EventRouter() = delete;

    static bool    RegisterEventSource(EVSYS_CHMUX_t producer, uint8 chan);
    static bool    RegisterEventListener(EVSYS_CHMUX_t listener, uint8 chan);
    static inline void    TriggerEvent(uint8 data, uint8 strobe) {
        EVSYS.DATA   = data;
        EVSYS.STROBE = strobe;
    }
};

#endif  /* XMEGA_DEFINED */
#endif	/* _MUNIX_EVENTSYS_H */

