#ifndef XMEGAOS_PORT_H
#define XMEGAOS_PORT_H
/*******************************************************************************
 ** Name: port.h                                                               **
 ** Description:              **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 ** The contents of this file are subject to the terms of the                 **
 ** Common Development and Distribution License, Version 1.0 only             **
 ** (the "License").  You may not use this file except in compliance          **
 ** with the License.                                                         **
 **                                                                           **
 ** You can find a copy of the license in the license.txt within              **
 ** this distribution or at http://www.munixos.net/licensing.                 **
 ** Software distributed under the License is distributed on an "AS IS"       **
 ** basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.           **
 ** See the License for the specific language governing permissions           **
 ** and limitations under the License.                                        **
 **                                                                           **
 ** When distributing Covered Code, include this CDDL header in each          **
 ** file and include the License file at $HOME/license.txt.                   **
 ** If applicable, add the following below this header, with the indicated    **
 ** fields enclosed by brackets "[]" replaced with your own identifying       **
 ** information: Portions Copyright [yyyy] [name of copyright owner]          **
 **                                                                           **
 **                                                                           **
 ** Copyright (c) 2009-2010  Barry Gian James <bjames@munixos.net>            **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Ref: $HeadURL: https://munix.svn.codeplex.com/svn/trunk/libmunix/bus.h $
 ******************************************************************************/
// Portions (C) 2011 OpenHouseware, LLC.
// All Rights Reserved

// $Id: bus.h 56282 2011-03-05 22:38:00Z bjames $
// Last Modified $DateTime$ by $Author: bjames $


#ifdef __AVR_XMEGA__
#include <avr/io.h>

#include <avr/interrupt.h>

#include "common.h"

///////////////////////////////[ Port
///
class PortManager
{
public:
	PortManager(void);
	~PortManager(void);

	// Configure interrupt of port
	void	ConfigurePins(PORT_t *p,uint8 m, uint8 s,uint8 i,PORT_OPC_t o,PORT_ISC_t isc) {
		uint8 temp = (uint8)o | isc | (s?PORT_SRLEN_bm:0) | (i?PORT_INVEN_bm:0);
		uint8 sreg = SREG; cli();
		PORTCFG.MPCMASK = m; p->PIN0CTRL = temp; SREG = sreg;
	}
	// ConfigureInterrupt(&PORTE,0,PORT_INT0LVL_MED_gc,PORT_INT0LVL_t,0xFF);
	void	ConfigureInterrupt(PORT_t * p, uint8 n, uint8 l, uint8 g, uint8 m) {
		p->INTCTRL = (p->INTCTRL & ~g)|l;
		if (n) p->INT1MASK = m;
		else p->INT0MASK = m;
	}

	// Set, Clear, Toggle ports, pins, individual pin, etc.
	void	SetDirection(PORT_t * p,uint8 v) { p->DIR = v; }
	void	SetInputPins(PORT_t * p,uint8 v) { p->DIRSET = v; }
	void	SetOutputPins(PORT_t * p,uint8 v) { p->DIRCLR = v; }
	void	ToggleDirection(PORT_t * p,uint8 v) { p->DIRTGL = v; }
	void	SetPinValue(PORT_t * p, uint8 v) { p->OUT = v; }
	void	SetPinGroupHigh(PORT_t * p,uint8 v) { p->OUTSET = v; }
	void	SetPinGroupLow(PORT_t * p, uint8 v) { p->OUTCLR = v; }
	void	TogglePinGroup(PORT_t * p, uint8 v) { p->OUTTGL = v; }
	register8	GetPortValue(PORT_t * p) { return (p->IN); }
	register8	GetInterruptFlags(PORT_t * p,register8 f) { return (p->INTFLAGS & f); }
	void	ClearInterruptFlags(PORT_t * p, uint8 v) { p->INTFLAGS = v; }
	void	SetOutputBit(PORT_t * p, uint8 v) { p->OUT = p->OUT|(1<<v); }
	void	ClearOutputBit(PORT_t * p, uint8 v) { p->OUT = p->OUT & ~(1<<v); }
	void	SetOutputPin(PORT_t * p, uint8 v) { p->DIR = p->DIR|(1<<v); }
	void	SetInputPin(PORT_t * p, uint8 v) { p->DIR = p->DIR & ~(1<<v); }


};





#endif
#endif