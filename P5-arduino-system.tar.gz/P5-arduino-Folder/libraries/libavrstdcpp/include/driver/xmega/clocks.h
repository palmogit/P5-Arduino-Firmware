#ifndef XMEGAOS_CLOCKS_H
#define XMEGAOS_CLOCKS_H
/*******************************************************************************
 ** Name: clocks.h                                                            **
 ** Description: An Xmega implementation of clock control.                    **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 ** The contents of this file are subject to the terms of the                 **
 ** Common Development and Distribution License, Version 1.0 only             **
 ** (the "License").  You may not use this file except in compliance          **
 ** with the License.                                                         **
 **                                                                           **
 ** You can find a copy of the license in the license.txt within              **
 ** this distribution or at http://www.munixos.net/licensing.                 **
 ** Software distributed under the License is distributed on an "AS IS"       **
 ** basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.           **
 ** See the License for the specific language governing permissions           **
 ** and limitations under the License.                                        **
 **                                                                           **
 ** When distributing Covered Code, include this CDDL header in each          **
 ** file and include the License file at $HOME/license.txt.                   **
 ** If applicable, add the following below this header, with the indicated    **
 ** fields enclosed by brackets "[]" replaced with your own identifying       **
 ** information: Portions Copyright [yyyy] [name of copyright owner]          **
 **                                                                           **
 **                                                                           **
 ** Copyright (c) 2009-2010  Barry Gian James <bjames@munixos.net>            **
 ** All rights reserved.                                                      **
 **                                                                           **
 ** Ref: $HeadURL: https://munix.svn.codeplex.com/svn/trunk/libmunix/bus.h $
 ******************************************************************************/
// Portions (C) 2011 OpenHouseware, LLC.
// All Rights Reserved

// $Id: bus.h 56282 2011-03-05 22:38:00Z bjames $
// Last Modified $DateTime$ by $Author: bjames $
#if defined(XMEGA_DEFINED)

class ClockManager
{
public:
	ClockManager(void);
	~ClockManager(void);

	void		Config32MHzClock(void);
	void		Config32kHzClock(void);
};

#endif
#endif