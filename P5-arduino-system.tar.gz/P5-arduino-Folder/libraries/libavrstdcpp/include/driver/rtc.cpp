
#if defined(XMEGA_DEFINED)

#include "common.h"
#include "rtc.h"


rtc_t::rtc_t()
{
    clocks = 0;
    *rtc_clocks = &RTC;

}


rtc_t::~rtc_t()
{
}

#endif