#ifndef _MUNIX_TIMER_H
#define	_MUNIX_TIMER_H
/*******************************************************************************
 ** Name: timer.h                                                             **
 ** Description: Declaration of filesystem paths.                             **
 **                                                                           **
 ** Open Source Initiative (OSI) Approved License                             **
 **                                                                           **
 **  Copyright (c) 2009-2010 Barry "Gian" James  <bjames@munixos.net>         **
 **  All rights reserved.                                                     **
 **                                                                           **
 **  Redistribution and use in source and binary forms, with or without       **
 **  modification, are permitted provided that the following conditions are   **
 **  met:                                                                     **
 **                                                                           **
 **  * Redistributions of source code must retain the above copyright notice, **
 **    this list of conditions and the following disclaimer.                  **
 **  * Redistributions in binary form must reproduce the above copyright      **
 **    notice, this list of conditions and the following disclaimer in the    **
 **    documentation and/or other materials provided with the distribution.   **
 **                                                                           **
 **  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS      **
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED **
 ** TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A           **
 ** PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT        **
 ** HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    **
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  **
 ** TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    **
 ** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    **
 ** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      **
 ** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        **
 ** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              **
 **                                                                           **
 ******************************************************************************/
// $Id: timer.h 56499 2011-03-14 15:25:03Z unknown $
// $Id: timer.h 56499 2011-03-14 15:25:03Z unknown $
#include "common.h"
#include "peripheral.h"
#include "ioport.h"

enum class WaveformMode
{
    Normal, PhasePWM8, PhasePWM9, PhasePWM10,
    CTCo, FastPWM8, FastPWM9, FastPWM10, PhaseFreqPWMi,
    PhaseFreqPWMo, PhasePWMi, PhasePWMo, CTCi,
    Reserved, FastPWMi, FastPWMo
};
enum class TimerDirection { Increment, Decrement };
enum class TimerClockSource { Stopped, clkio1, clkio8, clkio64, clkio256,
    clkio1024, ExternalFalling, ExternalRising };


class   Timer : public Peripheral
{
public:
    Timer(uint8 i, PeripheralResolution r);
    Timer(const Timer&) = delete;
    ~Timer() = delete;

    // deferred/implemented methods from Peripheral base
    bool        Setup();
    void        PowerUp();
    void        PowerDown();

    void        Start();
    void        Stop();
    uint16      Count();
    uint16      CTCMatch(uint16 m=0) { if (m) ctcMatch=m; return ctcMatch; }

private:
    uint16          ctcMatch;
    WaveformMode    mode;
    TimerDirection  countDir;
    TimerClockSource clockSource;

    union {
        IOPort * oc1a;
        IOPort * oc2a;
    };
    union {
        IOPort * oc1b;
        IOPort * oc2b;
    };


};

enum class WatchdogMode { Interrupt, SysReset, IntReset, Standard, Window, bjames };
// clock cycles to time:   16ms,32ms,64ms,0.125s,0.25s,0.5s,1s,   2s,   4s,    8s
enum class WatchdogTimeout { 
    wd2k, wd4k, wd8k,   wd16k,  wd32k,  wd64k, wd128k,
    wd256k, wd512k, wd1024k, bjames
};

class Watchdog : public Peripheral
{
public:
    Watchdog();
    Watchdog(const Watchdog &) = delete;
    ~Watchdog() = delete;

    bool    Setup();
    void    PowerUp();
    void    PowerDown();

private:
    WatchdogMode    mode;
    WatchdogTimeout timeout;
};

#endif	/* _MUNIX_TIMER_H */

