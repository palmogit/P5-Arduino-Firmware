#include "owKam.h"
#include "Streaming.h"
//using namespace std

extern owT *owTs;
extern int NowTs; // number of Tb sensors
extern owRH *owRHs;
extern int NowRHs; // number of Tb sensors
extern owPin owPins[];
extern int NowPins;

void owSensor::readScratchPad() {
  for(int i=0; i<9; i++) 
    scratchPad[i] = 0xAA;  
  OWHandle->reset();
  OWHandle->select(Address);
  OWHandle->write(T_READSCRATCH);
  if (verbose>100) {
    printAddress();Serial.print(" SP ");
  }
  for(int i=0; i<9; i++) {
    scratchPad[i] = OWHandle->read();
    if (verbose>100)
      Serial.print(scratchPad[i], HEX);
  }
  if (verbose>100)
    Serial.println();
  //  OWHandle->reset();
}

bool owSensor::isConnected()  {
  readScratchPad();
  return (OWHandle->crc8(scratchPad, 8) == scratchPad[T_SCRATCHPAD_CRC]);
}



owPin::owPin( int aPin) {
  pin=aPin;
  nSensors=0;
  nTs=0;
  nRHs=0;
  OWHandle=new OneWire((uint8_t) pin);
  Scan(false);
}
owPin::~owPin() {
  delete OWHandle;
}

void owPin::skipROM()  {  
  OWHandle->write(0xCC,false);
  OWHandle->reset();
}

// void owPin::ConvertAllBusT() {
//     OWHandle->reset();
//     OWHandle->write(T_STARTCONVO, false);
//     skipROM();
// }



void owPin::Scan(bool Populate, Print &myStream) {
  //  OWHandle->reset();
  OWHandle->Init(pin);
  OWHandle->reset_search();
  for (int i=0; i<8; i++) {
    devAddress[i]=0;
  }
  owRH *powRH=owRHs;
  if (owRHs != NULL) 
    do  { powRH = powRH->next; } while ( powRH->next != NULL);
  owT *powT=owTs;
  if (owTs != NULL) 
    do  { powT = powT->next; } while ( powT->next != NULL);
  while ( OWHandle->search(devAddress)) {
    if (devAddress[0] == 0x26) { //RH
      if (verbose>10) 
	printAddress(myStream);
      if (Populate && !owExists(devAddress)) {
	if (owRHs == NULL) {  // very first sensor
	  owRHs = new owRH (pin, OWHandle, devAddress);
	  powRH=owRHs;
	} else {
	  powRH->next= new  owRH (pin, OWHandle, devAddress);
	  powRH=powRH->next;
	}
	//	owRHs.push_back(owRH(pin, OWHandle, devAddress));
	nRHs++; nSensors++; NowRHs++;
	if (verbose>10) 
	   myStream << " New" << endl;
      } else 
	if (verbose>10) 
	   myStream << F(" Already Exists") << endl;
    }
    else if (devAddress[0] == 0x28) {  //T
      if (verbose>10) 
	printAddress(myStream);
      if (Populate && !owExists(devAddress)) {
	if (owTs == NULL) {  // very first sensor
	  owTs = new owT (pin, OWHandle, devAddress);
	  powT=owTs;
	} else {
	  powT->next= new owT (pin, OWHandle, devAddress);
	  powT=powT->next;
	}
	//	owTs.push_back(owT(pin, OWHandle, devAddress)); 
	nTs++; nSensors++; NowTs++;
	if (verbose>10) 
	   myStream << " New" << endl;
      } else 
	if (verbose>10) 
	  myStream << F(" Already Exists") << endl;
    }   
    else {
      if (verbose>10) {
	printAddress(myStream);
      }
    }
  }
}

void owPin::printAddress(Print &myStream) {
    // zero pad the address if necessary

  myStream << " Pin " << pin;

  if (devAddress[0] == 0x26) {
     myStream.print("  RH/TH ");
  }
  if (devAddress[0] == 0x28) {
     myStream.print(" Tsensor");
  }
  if (devAddress[0] >= 16) {
     myStream.print("(");    myStream.print(devAddress[0], HEX);   myStream.print(") ");
  }   for (uint8_t i = 1; i < 8; i++) {
    if (devAddress[i] < 16)  myStream.print("0");
     myStream.print(devAddress[i], HEX);
  }
}

owSensor::owSensor(int apin, OneWire *handle,  DeviceAddress address) {
  pin=apin;
  OWHandle=handle;
  for (int i=0; i<8; i++)
    Address[i]=address[i];
  lastData.tStamp=0;
  lastData.Status=-1;
  convTime=0;
  // if (address[0] == 0x26 ) 
  //   Type=1;
  // if (address[0] == 0x28 ) 
  //   Type=2;
}



void owSensor::printAddress(Print &myStream) {
  myStream << " Pin " << pin;

  if (Address[0] == 0x26) {
    myStream.print("  RH/TH ");
  }
  if (Address[0] == 0x28) {
    myStream.print(" Tsensor");
  }
  if (Address[0] >= 16) {
    myStream.print("(");   myStream.print(Address[0], HEX);  myStream.print(") ");
  }   for (uint8_t i = 1; i < 8; i++) {
    if (Address[i] < 16) 
      myStream.print("0");
    myStream.print(Address[i], HEX);
  }
}

bool owExists(DeviceAddress addr) {
  owRH *powRH=owRHs;
  owT *powT=owTs;
  if (powRH != NULL) {
    if (addressMatch(powRH->getAddress(),addr,8))
      return true;
    do {
      powRH=powRH->next;
      if (addressMatch(powRH->getAddress(),addr,8))
	return true;
    } while (powRH->next != NULL);
  }
  if (powT != NULL) {
    if (addressMatch(powT->getAddress(),addr,8))
      return true;
    do {
      powT=powT->next;
      if (addressMatch(powT->getAddress(),addr,8))
	return true;
    } while (powT->next != NULL);
  }

  return false;
}

bool owT::setResolution(uint8_t newResolution) {
  if (isConnected()) {
      switch (newResolution)
	{
	case 12:
	  scratchPad[T_CONFIGURATION] = T_TEMP_12_BIT;
	  break;
	case 11:
	  scratchPad[T_CONFIGURATION] = T_TEMP_11_BIT;
	  break;
            case 10:
	      scratchPad[T_CONFIGURATION] = T_TEMP_10_BIT;
	      break;
	case 9:
	default:
	  scratchPad[T_CONFIGURATION] = T_TEMP_9_BIT;
	  break;
	}
      writeScratchPad();
      return true;  // new value set
    }
    return false;
}


void owT::Convert() {
  if (millis()-convTime < DS18B20_CONVERSION_TIME)
    return;
  OWHandle->reset();
  OWHandle->select(Address);
  OWHandle->write(T_STARTCONVO, false);
  OWHandle->reset();
  convTime=millis();
}

void owT::writeScratchPad() {
  OWHandle->reset();
  OWHandle->select(Address);
  OWHandle->write(T_WRITESCRATCH);
  OWHandle->write(scratchPad[T_HIGH_ALARM_TEMP]); // high alarm temp
  OWHandle->write(scratchPad[T_LOW_ALARM_TEMP]); // low alarm temp
  OWHandle->write(scratchPad[T_CONFIGURATION]); // configuration
  OWHandle->write(T_COPYSCRATCH);
  delay(21);
}

void owT::readT() {
  if (millis()-convTime <  DS18B20_CONVERSION_TIME )
    return;
  OWHandle->reset();
  OWHandle->select(Address);
  if (!isConnected()) {
     lastData.Th= -99.99;
  }
  else {
    int16_t fpTemperature =
      (((int16_t) scratchPad[T_TEMP_MSB]) << 11) |
      (((int16_t) scratchPad[T_TEMP_LSB]) << 3);
    
   lastData.Th= (float)fpTemperature * 0.0078125;
   lastData.tStamp= convTime+DS18B20_CONVERSION_TIME/2;
  }
}

SensorData  *owT::getTemperature() {
  return &lastData;
}

bool addressMatch(uint8_t *a1, uint8_t *a2, int len) {
  for (int i=0; i<len; i++) 
    if (a1[i] != a2[i]) 
      return false;
  return true;
}

int freeRam () {
  extern int __heap_start, *__brkval;
  int v;
  return (int) &v - (__brkval == 0 ? (int) &__heap_start : (int) __brkval);
}

void software_Reset() {
// Restarts program from beginning but 
// does not reset the peripherals and registers
  asm volatile ("  jmp 0");  
}

void PrintMemoryAddress(uint16_t ptr) {
  unsigned char tmp;
  char string[]="0123456789ABCDEF";
  Serial.print(" ");
  tmp = *(1+ (unsigned char*) &ptr); // MSB
  Serial.print( string[tmp >> 4] );
  Serial.print( string[tmp & 0xF] );
  
  tmp = *(0+ (unsigned char*) &ptr); // LSB
  Serial.print( string[tmp >> 4] );
  Serial.print( string[tmp & 0xF] );
  Serial.print(" ");
} 

int ScanAll (Print &myStream) {
  if (verbose>10)
    Serial << F("ScanAll:  NowPins ") << NowPins << endl;
  for (int i=0; i<NowPins; i++) {
    owPins[i].Scan(true,myStream);
    myStream << "**Pin " << owPins[i].getpin() << " nTs=" 
	     <<  owPins[i].nTs <<  " nRHs=" << owPins[i].nRHs << "<br>" << endl; 
  }
}
int ClearAll (void) {  //desn't work :(((
  owRH *powRH=owRHs, *pRH;
  owT *powT=owTs, *pT;
  if (powRH != NULL) 
    do  { pRH=powRH; powRH = powRH->next; delete pRH; } while ( powRH->next != NULL);
  if (owTs != NULL) 
    do  { pT= powT; powT = powT->next; delete pT; } while ( powT->next != NULL);

}

// void owPin::setResolutionAllBusT(uint8_t newResolution  ) {
//   switch (newResolution)
//     {
//     case 12:
//       scratchPad[T_CONFIGURATION] = T_TEMP_12_BIT;
//       break;
//     case 11:
//       scratchPad[T_CONFIGURATION] = T_TEMP_11_BIT;
//       break;
//     case 10:
//       scratchPad[T_CONFIGURATION] = T_TEMP_10_BIT;
//       break;
//     case 9:
//     default:
//       scratchPad[T_CONFIGURATION] = T_TEMP_9_BIT;
//       break;
//     }
//   OWHandle->reset();
//   OWHandle->write(T_WRITESCRATCH);
//   skipROM();
//   OWHandle->write(scratchPad[T_HIGH_ALARM_TEMP]); // high alarm temp
//   OWHandle->write(scratchPad[T_LOW_ALARM_TEMP]); // low alarm temp
//   OWHandle->write(scratchPad[T_CONFIGURATION]); // configuration
//   OWHandle->write(T_COPYSCRATCH);
//   skipROM();
//   skipROM();
// }

void setResolutionAll_T(uint8_t newResolution  ) {
  for (owT *powT=owTs; powT != NULL && NowTs != 0 ; powT=getNextSensor(powT)) 
    powT->setResolution(newResolution);
}

void ConvertAll_T() {
  if (verbose > 10)
      Serial << " ConvertAll_T" << endl;
  for (owT *powT=owTs; powT != NULL && NowTs != 0 ; powT=getNextSensor(powT)) {
    powT->Convert(); 
  }
}

void readAll_T() {
  if (verbose > 10)
    Serial << F("readAll_T  ") << endl;
for (owT *powT=owTs; powT != NULL && NowTs != 0 ; powT=getNextSensor(powT)) {
      powT->readT(); 
  }
}


owT *getNextSensor( owT *powT) {
  if (NowTs == 0)
    return NULL;
  if (powT == NULL)
    return NULL;
  else {
    if (verbose>100) {
      Serial  <<" getNextSensor: current ";
      powT->printAddress();
      Serial  <<" nextptr ";
      PrintMemoryAddress((uint16_t)powT->next);
    }
    return (powT->next);
  }
}
