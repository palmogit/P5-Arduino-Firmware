Arduino Ethernet Library

===========================================================================
Ethernet: class to configure network settings.



===========================================================================
Server: class to listen for incoming network connections.

Server()