#ifndef OneKam_h
#define OneKam_h
#include <inttypes.h>
#include "Streaming.h"
#include <OneWire.h>
//#include <Print.h>

// DS18b20 commands
#define T_STARTCONVO      0x44  // Tells device to take a temperature reading and put it on the scratchpad
#define T_COPYSCRATCH     0x48  // Copy EEPROM
#define T_READSCRATCH     0xBE  // Read EEPROM
#define T_WRITESCRATCH    0x4E  // Write to EEPROM
#define T_RECALLSCRATCH   0xB8  // Reload from last known
#define T_READPOWERSUPPLY 0xB4  // Determine if device needs parasite power
#define T_ALARMSEARCH     0xEC  // Query bus for devices with an alarm condition

// DS18b20 scrathpad
#define T_TEMP_LSB        0
#define T_TEMP_MSB        1
#define T_HIGH_ALARM_TEMP 2
#define T_LOW_ALARM_TEMP  3
#define T_CONFIGURATION   4
#define T_INTERNAL_BYTE   5
#define T_COUNT_REMAIN    6
#define T_COUNT_PER_C     7
#define T_SCRATCHPAD_CRC  8

// DS18b20 resolution
#define T_TEMP_9_BIT  0x1F //  9 bit
#define T_TEMP_10_BIT 0x3F // 10 bit
#define T_TEMP_11_BIT 0x5F // 11 bit
#define T_TEMP_12_BIT 0x7F // 12 bit


// DS2438 commands
#define RH_CONV_T      0x44  // T conversion
#define RH_CONV_V      0xB4  // T conversion
#define RH_COPYSCRATCH     0x48  // Copy EEPROM
#define RH_READSCRATCH     0xBE  // Read EEPROM
#define RH_WRITESCRATCH    0x4E  // Write to EEPROM
#define RH_RECALLSCRATCH   0xB8  // Reload from last known

// DS2438 scrathpad
#define RH_CONFIG        0
#define RH_TEMP_LSB        1
#define RH_TEMP_MSB        2
#define RH_VOLT_LSB       3
#define RH_VOLT_MSB       4
#define RH_CURR_LSB       5
#define RH_CURR_MSB       6
#define RH_TRESH  7
#define RH_SCRATCHPAD_CRC  8

#define RH_CONF_VAD  0x1 // write: adc Vad
#define RH_CONF_VDD  0xF// write: adc VDD
#define RH_CONF_TB  0x10 // read: temp conv busy
#define RH_CONF_NVB  0x20 // read: memory busy 
#define RH_CONF_ADB  0x40 // read: adc busy


#define SENSOR_READOUT_PERIOD 2000 // milliseconds
#define DS18B20_CONVERSION_TIME 800 // milliseconds
#define DS2438_T_CONVERSION_TIME 10 // milliseconds
#define DS2438_AD_CONVERSION_TIME 4 // milliseconds
#define DS2438_CURRENT_CONVERSION_TIME 10 // milliseconds

// strange Franz's normalization with his comment
extern float coefficient; // because of adc1 to adc2 calibration


extern int verbose;
typedef uint8_t DeviceAddress[8];
typedef uint8_t ScratchPad[9];
extern ScratchPad scratchPad;
typedef  unsigned long TimeStamp;

typedef struct {
  TimeStamp tStamp;
  float value;
} SensorData;

class owSensor {
 protected:
  uint8_t pin;
  DeviceAddress Address;
  OneWire *OWHandle;
 public:
  int erc; // error counter
  void printSensorId( Print &myStream=Serial );
  owSensor(int apin, OneWire *handle,  DeviceAddress address);
  void printAddress( Print &myStream=Serial );
  uint8_t getAddressByte (int b) { return Address[b]; };
  uint8_t *getAddress () { return Address; };
  uint8_t _read() { return OWHandle->read();};
  uint8_t getPin () { return pin; };
};

class owT: public owSensor {
 public:
  owT *next; 
  SensorData Th;
 owT(int apin, OneWire *handle,  DeviceAddress address) : 
  owSensor(apin, handle, address) 
    {next=NULL; Th.tStamp=0; Th.value=-100.;} 
  void readScratchPad();
  bool isConnected(); 
  void Convert();
  void readT();
  SensorData *getTemperature();
  bool setResolution(uint8_t res=12);
  void writeScratchPad();
};

class owRH: public owSensor {
 public:
  owRH *next;
  SensorData Th;
  SensorData Rh;
  SensorData VDD;
  SensorData VAD;
  SensorData Dp;
  SensorData Dp2;

 owRH(int apin, OneWire *handle,  DeviceAddress address) : 
  owSensor(apin, handle,  address)     
    {next=NULL; Th.tStamp=0; Th.value=-100.; 
      Rh.tStamp=0; Rh.value=-100.;
      Dp.tStamp=0; Dp.value=-100.;
      Dp2.tStamp=0; Dp2.value=-100.;
      VAD.tStamp=0; VAD.value=-100.;
      VDD.tStamp=0; VDD.value=-100.;
    }
  void readScratchPad();
  bool isConnected(); 
  void writeConfig(uint8_t conf=RH_CONV_V);
  void Convert();
  void ConvertVDD();
  void readT();
  void readRH();
  void readVDD();
  void copy2EEPROM();
  
  SensorData *getTemperature() { return &Th; };
  SensorData *getRh()   { return &Rh; };
  SensorData *getDp()   { return &Dp; };
  SensorData *getVAD()  { return &VAD; };
  SensorData *getVDD()  { return &VDD; };
  SensorData *getDp2()  { return &Dp2; };

  void calcRhDp();

 };

class owPin {
 private:
  int pin;
  DeviceAddress devAddress;
  
 public:
  int nSensors;
  int nTs;
  int nRHs;
  owPin();
  ~owPin();
  owPin( int aPin);
  int getpin(void) { return pin;};
  void printAddress(Print &myStream=Serial);
  int Reset();
  void Scan(bool Populate, Print &myStream=Serial);
  OneWire *OWHandle;
  void skipROM();
  //  void ConvertAllBusT();
  //  void setResolutionAllBusT(uint8_t newResolution  );
};


bool owExists(DeviceAddress addr);
int freeRam ();
void software_Reset();
void PrintMemoryAddress(uint16_t ptr);
bool addressMatch(uint8_t *a1, uint8_t *a2, int len);
int ScanAll (Print &myStream);
int ClearAll ();
owT *getNextSensor( owT *powT);
owRH *getNextSensor( owRH *powRH);
void printAd(bool a, Print &myStream);
void setResolutionAll_T(uint8_t newResolution  );
void ConvertAll_T();
void readAll_T();
void ConvertAll_RH_T();
void ConvertAll_RH_VDD();
void readAll_RH_T();
void readAll_RH_VDD();
void calcAll_RH_DP();
#endif
